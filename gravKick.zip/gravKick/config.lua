
Config = {}

Config = {
    messagePrefix = "", -- This is the prefix for the messages that the user will get - Example: [System] No perms!
    webhookURL = "", -- Webhook for the kick log to be sent 
    embedColor = "", -- Color of the kick log embed
    embedName = "", -- Name of the kick log embed
    discordURL = "" -- Discord url provided in the FiveM kick message
}
