--------------------------------------
------Created By Grav------
--https://github.com/Gravxd--
--------------------------------------

author 'Grav'
description 'Simple kick command that lets you moderate with ease! Thanks to badger.'
server_script {
    'config.lua',
    'server.lua'
}
client_scripts {
    'config.lua',
    'client.lua'
}

-- Credits to Badger! https://badger.store