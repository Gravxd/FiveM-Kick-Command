# FiveM-Kick-Command
Simple command that lets you kick players from chat! [PERMISSION BASED]

`Setup`

**1)** Go to config.lua --> Fill in all of the fields required

**2)** Go to your `server.cfg` and add `add_ace group.admin gravKick allow` # group.admin should be the ace permissions group setup for the users that you want to be able to use the command.

It can be used also for multiple groups:

`add_ace group.admin gravKick allow`
`add_ace group.mod gravKick allow`

**3)** Add the line '`start gravKick`' to your `server.cfg`

**4)** The script is now ready for use!

**Join the [support server](https://discord.gg/ZYHxxba) for help!**

`Usage`

/kick [id] [reason]

Logs the player's identifiers. (Steam, License + Discord)

`How it looks!`

![Discord!](https://i.imgur.com/tGnmSs3.png)

![Kick Message!](https://i.imgur.com/4SeA3uo.png)
